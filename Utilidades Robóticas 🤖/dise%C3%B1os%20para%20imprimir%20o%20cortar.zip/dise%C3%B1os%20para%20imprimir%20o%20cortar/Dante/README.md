Diseños de Dante
